import React from 'react';
import AnimatedBackground from './components/AnimatedBackground';
import BirthdayWish from './components/BirthdayWish';
import Footer from './components/Footer';
import HappyBirthdayMessage from './components/HappyBirthdayMessage';
import WishingPara from './components/WishingPara';

function App() {
  const birthdayPerson = 'Jerome Santosh Annan';
  const backgroundColor = 'bg-gradient-to-br from-indigo-700 to-purple-400';
  const textColor = 'text-gray-100';

  return (
    <div className={`min-h-screen flex flex-col ${backgroundColor} relative overflow-hidden`}>
      <AnimatedBackground />
      <main className="container mx-auto py-8 flex-grow flex items-center justify-center relative z-10 px-4 sm:px-0">
        <div className="text-center">
          <HappyBirthdayMessage name={birthdayPerson} textColor={textColor} />
          <WishingPara name={birthdayPerson} textColor={textColor} />
          <BirthdayWish name={birthdayPerson} textColor={textColor} />
        </div>
      </main>
      <Footer author="Santhakumar K" textColor={textColor} />
    </div>
  );
}

export default App;
