import React from 'react';

function AnimatedBackground() {
  return (
    <div className="absolute inset-0">
      <div className="firecrackers">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="firecracker"></div>
        ))}
      </div>
      <style jsx>{`
        .firecrackers {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
        }
        .firecracker {
          position: absolute;
          width: 10px;
          height: 10px;
          background-color: white;
          border-radius: 50%;
          animation: firecracker-animation ${Math.random() * 3 + 2}s linear infinite;
          top: ${Math.random() * 100}%;
          left: ${Math.random() * 100}%;
        }
        @keyframes firecracker-animation {
          0% {
            transform: translateY(0) scale(1);
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) scale(0.5);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}

export default AnimatedBackground;
