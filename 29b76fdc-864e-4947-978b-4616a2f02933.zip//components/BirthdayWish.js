import React, { useState } from 'react';

function BirthdayWish({ name, textColor }) {
  const [wish, setWish] = useState('');
  const [submittedWish, setSubmittedWish] = useState('');

  const handleWishChange = (event) => {
    setWish(event.target.value);
  };

  const handleSubmitWish = () => {
    if (wish.trim() !== '') {
      setSubmittedWish(wish);
      setWish('');
    }
  };

  return (
    <section className="mb-8">
      <h2 className={`text-2xl font-semibold mb-4 ${textColor}`}>Leave a Birthday Wish for {name}! 🎉</h2>
      <textarea
        className="w-full p-3 border rounded-md mb-2 shadow-sm focus:ring focus:ring-blue-200 text-gray-700"
        rows="4"
        placeholder="Write your birthday message here..."
        value={wish}
        onChange={handleWishChange}
      ></textarea>
      <button
        className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-2 px-4 rounded shadow-md transition duration-300"
        onClick={handleSubmitWish}
      >
        Send Wish
      </button>

      {submittedWish && (
        <div className={`mt-4 p-3 bg-green-50 border border-green-400 rounded-md text-gray-700`}>
          <p>Your wish: {submittedWish}</p>
        </div>
      )}
    </section>
  );
}

export default BirthdayWish;
