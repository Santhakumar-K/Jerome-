import React from 'react';

function Footer({ author, textColor }) {
  return (
    <footer className="bg-gray-900 text-white py-4 text-center">
      <p className={textColor}>Created by {author}</p>
    </footer>
  );
}

export default Footer;
