import React from 'react';

function HappyBirthdayMessage({ name, textColor }) {
  return (
    <div className={`text-4xl font-extrabold bg-clip-text bg-gradient-to-r from-yellow-400 to-red-600 mb-4 animate-pulse ${textColor}`}>
      Happy Birthday {name}!
    </div>
  );
}

export default HappyBirthdayMessage;
