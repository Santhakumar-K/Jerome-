import React from 'react';

function WishingPara({ name, textColor }) {
  return (
    <section className="mb-8">
      <p className={`text-lg ${textColor}`}>
        Wishing you a very happy birthday, {name}! May your day be filled with joy, laughter, and all the things you love. 🎉🎂
      </p>
    </section>
  );
}

export default WishingPara;
